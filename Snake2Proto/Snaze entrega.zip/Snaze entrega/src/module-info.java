/**
 * 
 */
/**
 * 
 */
module Snake2Proto {
	requires java.desktop;
}